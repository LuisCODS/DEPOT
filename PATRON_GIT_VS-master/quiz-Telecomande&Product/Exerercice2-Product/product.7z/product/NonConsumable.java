
package product;

public class NonConsumable extends Type {



}