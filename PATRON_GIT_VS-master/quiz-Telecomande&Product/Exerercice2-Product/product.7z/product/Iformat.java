
package product;

public interface Iformat {


    public abstract void Print();

}