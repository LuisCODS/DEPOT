package product;

public class Txt implements Iformat {

	
	
	@Override
	public void Print() {
		System.out.println("IMPRESSION... FORMAT TXT");			
		
	}

}