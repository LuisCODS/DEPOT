
package product;


public interface Iexpiration {

	
    public abstract String GetExpiration();


}