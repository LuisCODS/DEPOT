
package product;

public class Pdf implements Iformat {

	@Override
	public void Print() {
		System.out.println("IMPRESSION... FORMAT PDF");			
		
	}

}