package product;

public class Html implements Iformat {

	@Override
	public void Print() {
		System.out.println("IMPRESSION... FORMAT HTML");			
		
	}

}